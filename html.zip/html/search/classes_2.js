var searchData=
[
  ['edittransactiondialog',['EditTransactionDialog',['../class_edit_transaction_dialog.html',1,'']]]
];
