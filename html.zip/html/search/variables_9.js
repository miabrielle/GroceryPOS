var searchData=
[
  ['totalrevenue',['totalRevenue',['../class_item.html#a93857ef5f77c1e4ca5bbd685b7483bfc',1,'Item']]],
  ['transactionselected',['transactionSelected',['../class_main_window.html#acd69ebd243c08de70e538d23f4344379',1,'MainWindow']]],
  ['transactionselectedpointer',['transactionSelectedPointer',['../class_edit_transaction_dialog.html#adf50dcc60c9a6327e90c079b6f2bc6da',1,'EditTransactionDialog']]],
  ['transactionstablepointer',['transactionsTablePointer',['../class_edit_transaction_dialog.html#a114ef30403f4dd0f572d2f4d07e23b8b',1,'EditTransactionDialog']]]
];
