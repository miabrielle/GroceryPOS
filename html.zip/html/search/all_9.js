var searchData=
[
  ['purchasedate',['purchaseDate',['../class_transaction.html#aaf954eab2c7fcc26cc24faa3864d72ae',1,'Transaction']]]
];
