var searchData=
[
  ['updateitemindb',['updateItemInDB',['../class_d_b_manager.html#a2478427cd7c5d124b578c9af5532756a',1,'DBManager']]],
  ['updatetransactionindb',['updateTransactionInDB',['../class_d_b_manager.html#a8cbe923eda9c2979817145fc1674c0fc',1,'DBManager']]]
];
