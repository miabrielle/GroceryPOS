var searchData=
[
  ['dbmanager',['DBManager',['../class_d_b_manager.html',1,'']]]
];
