var indexSectionsWithContent =
{
  0: "acdegilmopqrstu~",
  1: "cdeilmt",
  2: "u",
  3: "acdeilmt",
  4: "acdegilmorstu~",
  5: "cdeimpqrstu"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables"
};

