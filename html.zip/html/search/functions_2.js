var searchData=
[
  ['dbmanager',['DBManager',['../class_d_b_manager.html#afb4f09d26522754aab71b801716a8325',1,'DBManager']]],
  ['deleteitem',['deleteItem',['../class_d_b_manager.html#abf872cb42a3940365d38a9866e98dc02',1,'DBManager']]],
  ['displayitems',['displayItems',['../class_main_window.html#a85a5a959c223f35f1c238265d3a2ed38',1,'MainWindow']]]
];
