var searchData=
[
  ['dbmanager_2ecpp',['dbmanager.cpp',['../dbmanager_8cpp.html',1,'']]],
  ['dbmanager_2eh',['dbmanager.h',['../dbmanager_8h.html',1,'']]]
];
