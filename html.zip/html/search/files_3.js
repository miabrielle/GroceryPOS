var searchData=
[
  ['edittransactiondialog_2ecpp',['edittransactiondialog.cpp',['../edittransactiondialog_8cpp.html',1,'']]],
  ['edittransactiondialog_2eh',['edittransactiondialog.h',['../edittransactiondialog_8h.html',1,'']]]
];
