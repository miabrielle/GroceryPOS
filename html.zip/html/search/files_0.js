var searchData=
[
  ['admincp_2ecpp',['admincp.cpp',['../admincp_8cpp.html',1,'']]],
  ['admincp_2eh',['admincp.h',['../admincp_8h.html',1,'']]]
];
