var searchData=
[
  ['quantitypurchased',['quantityPurchased',['../class_transaction.html#ac4d79a9bd07ce1a8eb5f990afcd9c8f0',1,'Transaction']]],
  ['quantitysold',['quantitySold',['../class_item.html#aea4726d371021c73b537884ec5a7d0d7',1,'Item']]]
];
