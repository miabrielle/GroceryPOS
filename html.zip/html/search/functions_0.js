var searchData=
[
  ['addcustomersvectortotable',['addCustomersVectorToTable',['../class_main_window.html#a5c0d3b2e6e475c3c3454d78fda83f0a4',1,'MainWindow']]],
  ['addcustomervectortotable',['addCustomerVectorToTable',['../class_member_change_status.html#a3b34636daca94b977fe1348016ffe975',1,'MemberChangeStatus']]],
  ['additem',['addItem',['../class_d_b_manager.html#a197f397d8538dfd4eed2d30274c08f02',1,'DBManager']]],
  ['addtransactionsvectortotable',['addTransactionsVectorToTable',['../class_main_window.html#ab352d92d62d6c6480120d69db6bcade0',1,'MainWindow']]],
  ['authenticateuser',['authenticateUser',['../class_d_b_manager.html#a8cc1763659f3188e4fb63b8b4a0a1712',1,'DBManager']]]
];
