var searchData=
[
  ['edittransactiondialog',['EditTransactionDialog',['../class_edit_transaction_dialog.html#a741bf5ff4b2094a5eb1f9227feb85565',1,'EditTransactionDialog']]]
];
