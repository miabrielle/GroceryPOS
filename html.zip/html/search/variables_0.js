var searchData=
[
  ['changestatus',['changeStatus',['../class_customer.html#a814891a66b57f11e27b43a6453060650',1,'Customer']]],
  ['customerid',['customerID',['../class_customer.html#a3f2558edde33b441a708fdd6ff49f9db',1,'Customer::customerID()'],['../class_transaction.html#ac7ff15a48e4d48b06608334ddff20084',1,'Transaction::customerID()']]],
  ['customername',['customerName',['../class_customer.html#a0e935eea307e60801d883c3765f319c0',1,'Customer']]]
];
