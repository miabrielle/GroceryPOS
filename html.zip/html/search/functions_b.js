var searchData=
[
  ['transaction',['Transaction',['../class_transaction.html#ab47005b855d38bc324bb79fd023baa13',1,'Transaction::Transaction()'],['../class_transaction.html#af43a192acc9008875d5594c080d09987',1,'Transaction::Transaction(int customerID, QString itemName, int quantityPurchased, QString purchaseDate)']]]
];
