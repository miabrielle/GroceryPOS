var searchData=
[
  ['isadmin',['isAdmin',['../class_main_window.html#a735c2c1dcdb1692dbcc3c01a9f83b3d3',1,'MainWindow']]],
  ['itemname',['itemName',['../class_item.html#ae145622d2df65a4a45979fd7933b30c7',1,'Item::itemName()'],['../class_transaction.html#ad59a14606a02e67618590bc5a2889ace',1,'Transaction::itemName()']]],
  ['itemprice',['itemPrice',['../class_item.html#ac2e5d35498589a7db983f488f3d7aa47',1,'Item']]],
  ['itemslist',['itemsList',['../class_main_window.html#a9b9b2f28456dcf2bbcd0b11d52853e61',1,'MainWindow']]]
];
