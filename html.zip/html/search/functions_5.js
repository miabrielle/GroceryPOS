var searchData=
[
  ['initdb',['initDB',['../class_d_b_manager.html#ab3ef182b7cbcf7f688ff4bf4b8af0374',1,'DBManager']]]
];
