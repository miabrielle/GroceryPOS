var searchData=
[
  ['db',['db',['../class_d_b_manager.html#a5399b255096671fc8a5dd3ebf2dd0507',1,'DBManager']]],
  ['dbpointer',['dbPointer',['../class_main_window.html#a08dcc3bde043f0a69f82ea8badad8a3c',1,'MainWindow::dbPointer()'],['../class_edit_transaction_dialog.html#aed38ea4d4488854b505c0a4e1100daa0',1,'EditTransactionDialog::dbPointer()'],['../class_login_window.html#a35a9551b384df84bcfd847988a6c0bbb',1,'LoginWindow::dbPointer()'],['../class_member_change_status.html#a445471d1550710dccfb41bd51940e28a',1,'MemberChangeStatus::dbPointer()']]]
];
