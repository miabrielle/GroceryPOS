var searchData=
[
  ['totalrevenue',['totalRevenue',['../class_item.html#a93857ef5f77c1e4ca5bbd685b7483bfc',1,'Item']]],
  ['transaction',['Transaction',['../class_transaction.html',1,'Transaction'],['../class_transaction.html#ab47005b855d38bc324bb79fd023baa13',1,'Transaction::Transaction()'],['../class_transaction.html#af43a192acc9008875d5594c080d09987',1,'Transaction::Transaction(int customerID, QString itemName, int quantityPurchased, QString purchaseDate)']]],
  ['transaction_2ecpp',['transaction.cpp',['../transaction_8cpp.html',1,'']]],
  ['transaction_2eh',['transaction.h',['../transaction_8h.html',1,'']]],
  ['transactionselected',['transactionSelected',['../class_main_window.html#acd69ebd243c08de70e538d23f4344379',1,'MainWindow']]],
  ['transactionselectedpointer',['transactionSelectedPointer',['../class_edit_transaction_dialog.html#adf50dcc60c9a6327e90c079b6f2bc6da',1,'EditTransactionDialog']]],
  ['transactionstablepointer',['transactionsTablePointer',['../class_edit_transaction_dialog.html#a114ef30403f4dd0f572d2f4d07e23b8b',1,'EditTransactionDialog']]]
];
